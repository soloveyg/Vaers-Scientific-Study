import json;

def read_JSON(json_file_path):   
    # Read the JSON file
    try:
        with open(json_file_path, 'r') as file:
            content = json.load(file)
            return content
    except Exception as e:
        print(f"Failed to read JSON file: {e}")
        return None