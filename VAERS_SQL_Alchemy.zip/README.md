# VAERS-Scientific-Study
VAERS Scientific Study on Vaccines using SQL and Python scripts.

### Available  reports:
<a href="https://html-preview.github.io/?url=https://github.com/soloveyg/Vaers-Scientific-Study/blob/main/html/Deaths%20Counts%20by%20Vaccine%20Name%20and%20Date%20Range.html">Deaths Counts by Vaccine Name and Date Range</a>
